Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - LittleRobotSoundFactory ( https://freesound.org/people/LittleRobotSoundFactory/ )

You can find this pack online at: https://freesound.org/people/LittleRobotSoundFactory/packs/16681/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 270344__littlerobotsoundfactory__shoot-00.wav
    * url: https://freesound.org/s/270344/
    * license: Attribution
  * 270343__littlerobotsoundfactory__shoot-01.wav
    * url: https://freesound.org/s/270343/
    * license: Attribution
  * 270342__littlerobotsoundfactory__pickup-03.wav
    * url: https://freesound.org/s/270342/
    * license: Attribution
  * 270341__littlerobotsoundfactory__pickup-04.wav
    * url: https://freesound.org/s/270341/
    * license: Attribution
  * 270340__littlerobotsoundfactory__pickup-01.wav
    * url: https://freesound.org/s/270340/
    * license: Attribution
  * 270339__littlerobotsoundfactory__pickup-02.wav
    * url: https://freesound.org/s/270339/
    * license: Attribution
  * 270338__littlerobotsoundfactory__open-01.wav
    * url: https://freesound.org/s/270338/
    * license: Attribution
  * 270337__littlerobotsoundfactory__pickup-00.wav
    * url: https://freesound.org/s/270337/
    * license: Attribution
  * 270336__littlerobotsoundfactory__shoot-02.wav
    * url: https://freesound.org/s/270336/
    * license: Attribution
  * 270335__littlerobotsoundfactory__shoot-03.wav
    * url: https://freesound.org/s/270335/
    * license: Attribution
  * 270334__littlerobotsoundfactory__jingle-lose-01.wav
    * url: https://freesound.org/s/270334/
    * license: Attribution
  * 270333__littlerobotsoundfactory__jingle-win-00.wav
    * url: https://freesound.org/s/270333/
    * license: Attribution
  * 270332__littlerobotsoundfactory__hit-03.wav
    * url: https://freesound.org/s/270332/
    * license: Attribution
  * 270331__littlerobotsoundfactory__jingle-achievement-00.wav
    * url: https://freesound.org/s/270331/
    * license: Attribution
  * 270330__littlerobotsoundfactory__jingle-achievement-01.wav
    * url: https://freesound.org/s/270330/
    * license: Attribution
  * 270329__littlerobotsoundfactory__jingle-lose-00.wav
    * url: https://freesound.org/s/270329/
    * license: Attribution
  * 270328__littlerobotsoundfactory__hero-death-00.wav
    * url: https://freesound.org/s/270328/
    * license: Attribution
  * 270327__littlerobotsoundfactory__hit-00.wav
    * url: https://freesound.org/s/270327/
    * license: Attribution
  * 270326__littlerobotsoundfactory__hit-01.wav
    * url: https://freesound.org/s/270326/
    * license: Attribution
  * 270325__littlerobotsoundfactory__hit-02.wav
    * url: https://freesound.org/s/270325/
    * license: Attribution
  * 270324__littlerobotsoundfactory__menu-navigate-00.wav
    * url: https://freesound.org/s/270324/
    * license: Attribution
  * 270323__littlerobotsoundfactory__jump-03.wav
    * url: https://freesound.org/s/270323/
    * license: Attribution
  * 270322__littlerobotsoundfactory__menu-navigate-02.wav
    * url: https://freesound.org/s/270322/
    * license: Attribution
  * 270321__littlerobotsoundfactory__menu-navigate-01.wav
    * url: https://freesound.org/s/270321/
    * license: Attribution
  * 270320__littlerobotsoundfactory__jump-00.wav
    * url: https://freesound.org/s/270320/
    * license: Attribution
  * 270319__littlerobotsoundfactory__jingle-win-01.wav
    * url: https://freesound.org/s/270319/
    * license: Attribution
  * 270318__littlerobotsoundfactory__jump-02.wav
    * url: https://freesound.org/s/270318/
    * license: Attribution
  * 270317__littlerobotsoundfactory__jump-01.wav
    * url: https://freesound.org/s/270317/
    * license: Attribution
  * 270316__littlerobotsoundfactory__open-00.wav
    * url: https://freesound.org/s/270316/
    * license: Attribution
  * 270315__littlerobotsoundfactory__menu-navigate-03.wav
    * url: https://freesound.org/s/270315/
    * license: Attribution
  * 270311__littlerobotsoundfactory__explosion-03.wav
    * url: https://freesound.org/s/270311/
    * license: Attribution
  * 270310__littlerobotsoundfactory__explosion-04.wav
    * url: https://freesound.org/s/270310/
    * license: Attribution
  * 270309__littlerobotsoundfactory__craft-00.wav
    * url: https://freesound.org/s/270309/
    * license: Attribution
  * 270308__littlerobotsoundfactory__explosion-00.wav
    * url: https://freesound.org/s/270308/
    * license: Attribution
  * 270307__littlerobotsoundfactory__explosion-01.wav
    * url: https://freesound.org/s/270307/
    * license: Attribution
  * 270306__littlerobotsoundfactory__explosion-02.wav
    * url: https://freesound.org/s/270306/
    * license: Attribution
  * 270305__littlerobotsoundfactory__climb-rope-loop-00.wav
    * url: https://freesound.org/s/270305/
    * license: Attribution
  * 270304__littlerobotsoundfactory__collect-point-00.wav
    * url: https://freesound.org/s/270304/
    * license: Attribution
  * 270303__littlerobotsoundfactory__collect-point-01.wav
    * url: https://freesound.org/s/270303/
    * license: Attribution
  * 270302__littlerobotsoundfactory__collect-point-02.wav
    * url: https://freesound.org/s/270302/
    * license: Attribution


